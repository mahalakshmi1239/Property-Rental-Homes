import datetime
import os
import re

from bson import ObjectId
from flask import Flask, request, redirect, render_template, session
import pymongo


my_collections = pymongo.MongoClient("mongodb://localhost:27017")
my_db = my_collections["Property_Rental_Homes"]
admin_col = my_db["Admin"]
location_col = my_db["Locations"]
community_col = my_db["Communities"]
amenities_col = my_db["amenities"]
leasing_officer_col = my_db["Leasing Officers"]
property_col = my_db["Properties"]
customer_col = my_db["Customers"]
appointment_col = my_db["Appointments"]
leasings_col = my_db['Leasings']
rent_request_col = my_db["Rent_requests"]
payment_col = my_db["Payments"]


app= Flask(__name__)
app.secret_key="homes"

App_Root = os.path.dirname(__file__)
App_Root = App_Root + "/static"

if admin_col.count_documents({})==0:
    admin_col.insert_one({"username":"admin","password":"admin", "role":"Admin"})

@app.route("/")
def home():
    return render_template("home.html")


@app.route("/admin_login")
def admin_login():
    return render_template("admin_login.html")


@app.route("/admin_login_action" , methods=['post'])
def admin_login_action():
    username = request.form.get("username")
    password = request.form.get("password")
    query={"username":username, "password":password}
    admin = admin_col.find_one(query)

    if admin is not None:
        session["admin_id"] = str(admin["_id"])
        session["role"] = "admin"
        return redirect("/admin_home")
    else:
        return render_template("msg.html", message="Invalid Login Details")


@app.route("/admin_home")
def admin_home():
    return render_template("admin_home.html")


@app.route("/add_locations")
def add_locations():
    return render_template("add_locations.html")


@app.route("/add_locations_action",methods=['post'])
def add_locations_action():
    location_name = request.form.get("location_name")
    query={"$or":[{"location_name":location_name}]}
    count = location_col.count_documents(query)
    if count == 0:
        query={"location_name":location_name}
        location_col.insert_one(query)
        return {"message":"Location Added Successfully"}
    else:
        return  {"message":"This location already added"}


@app.route("/get_locations")
def get_locations():
    locations = location_col.find()
    locations = list(locations)
    return render_template("view_locations.html",locations=locations)


@app.route("/add_community")
def add_community():
    locations = location_col.find()
    return  render_template("add_community.html", locations=locations)


@app.route("/add_community_action", methods=['post'])
def add_community_action():
    community_name = request.form.get("community_name")
    location_id = request.form.get("location_id")
    address = request.form.get("address")
    name = request.form.get("name")
    email = request.form.get("email")
    password = request.form.get("password")
    phone = request.form.get("phone")
    gender = request.form.get("gender")
    age = request.form.get("age")
    query = {"community_name":community_name}
    count = community_col.count_documents(query)
    query = {"$or":[{"email":email,"phone":phone}]}
    count = leasing_officer_col.count_documents(query)
    if count==0:
        query = {"community_name":community_name, "location_id": ObjectId(location_id),"address":address}
        result = community_col.insert_one(query)
        community_id = result.inserted_id
        query = {"name": name, "email": email,"password":password ,"phone": phone, "gender": gender, "age": age,"community_id": ObjectId(community_id)}
        leasing_officer_col.insert_one(query)
        return {"message": "Added successfully"}
    else:
        return {"message": "Invalid Details"}


@app.route("/view_community")
def view_community():
    communities = community_col.find()
    return render_template("view_community.html",communities=communities,get_locations_by_location_id=get_locations_by_location_id,get_leasing_officer_by_community_id=get_leasing_officer_by_community_id)

def get_locations_by_location_id(location_id):
    query = {"_id": ObjectId(location_id)}
    locations = location_col.find_one(query)
    return  locations

def get_leasing_officer_by_community_id(community_id):
    query = {"community_id":ObjectId(community_id)}
    leasing_officers = leasing_officer_col.find(query)
    return  leasing_officers


@app.route("/add_amenities")
def add_amenities():
    community_id = request.args.get("community_id")
    communities = community_col.find()
    communities = list(communities)
    return render_template("add_amenities.html",communities=communities,community_id=community_id, str=str)


@app.route("/add_amenities_action", methods=['post'])
def add_amenities_action():
    amenity_name = request.form.get("amenity_name")
    community_id = request.form.get("community_id")
    description = request.form.get("description")
    query={"amenity_name":amenity_name}
    count = amenities_col.count_documents(query)
    if count == 0:
        query={"amenity_name":amenity_name,"community_id":ObjectId(community_id),"description":description}
        print(query)
        amenities_col.insert_one(query)
        return {"message":"Amunity added successfully"}
    else:
        return {"message":"Duplicate details"}


@app.route("/get_amenities")
def get_amenities():
    community_id = request.args.get("community_id")
    query= {"community_id":ObjectId(community_id)}
    amenities = amenities_col.find(query)
    return render_template("view_amenities.html",amenities=amenities,community_id=community_id)


@app.route("/leasing_officer_login")
def leasing_officer_login():
    return  render_template("leasing_officer_login.html")

@app.route("/leasing_officer_login_action", methods=['post'])
def leasing_officer_login_action():
    email = request.form.get("email")
    password = request.form.get("password")
    query = {"email": email, "password": password}
    count = leasing_officer_col.count_documents(query)
    if count>0:
        leasing_officer = leasing_officer_col.find_one(query)
        session["leasing_officer_id"] =str(leasing_officer["_id"])
        session["role"] = "leasing_officer"
        return redirect("/leasing_officer_home")
    else:
        return render_template("msg.html", message="Invalid Login Details")

@app.route("/leasing_officer_home")
def leasing_officer_home():
    leasing_officer_id = session['leasing_officer_id']
    query = {"_id": ObjectId(leasing_officer_id)}
    leasing_officers = leasing_officer_col.find(query)
    return render_template("leasing_officer_home.html",leasing_officers=leasing_officers)


@app.route("/add_property")
def add_property():
    community_id = request.args.get("community_id")
    communities = community_col.find()
    communities = list(communities)
    return render_template("add_property.html", communities=communities, community_id=community_id, str=str)



@app.route("/add_property_action", methods=['post'])
def add_property_action():
    property_title = request.form.get("property_title")
    property_type = request.form.get("property_type")
    no_of_sft = request.form.get("no_of_sft")
    community_id = request.form.get("community_id")
    rent_per_month = request.form.get("rent_per_month")
    no_of_bedrooms = request.form.get("no_of_bedrooms")
    no_of_bathrooms = request.form.get("no_of_bathrooms")
    picture = request.files.get("picture")
    status = "Available for rent"
    query = {"property_title":property_title}
    count=property_col.count_documents(query)
    if count >0:
        return render_template("message.html", message="duplicate property details")
    try:
        path = App_Root + "/picture/" + picture.filename
        picture.save(path)
        query = {"property_title":property_title,"property_type":property_type,"no_of_sft":no_of_sft,"community_id":ObjectId(community_id),"rent_per_month":rent_per_month,"no_of_bedrooms":no_of_bedrooms,"no_of_bathrooms":no_of_bathrooms,"picture":picture.filename, "status":status}
        property_col.insert_one(query)
        return render_template("message.html",message="property added successfully")
    except Exception as e:
        return render_template("message.html", message="Invalid property details")

@app.route("/search_property")
def search_property():
    locations = location_col.find()
    communities = community_col.find()
    return render_template("search_property.html",communities=communities,locations=locations)


@app.route("/get_property_by_location_community")
def get_property_by_location_community():
    property_type = request.args.get("property_type")
    location_id = request.args.get("location_id")
    community_id = request.args.get("community_id")
    no_of_bedrooms = request.args.get("no_of_bedrooms")
    if session['role'] == 'leasing_officer':
        leasing_officer_id = session['leasing_officer_id']
        query = {"_id": ObjectId(leasing_officer_id)}
        leasing_officer = leasing_officer_col.find_one(query)
        community_id = leasing_officer['community_id']
        community_id = str(community_id)
    property_type_like = re.compile(".*"+property_type+".*",re.IGNORECASE)
    if location_id == "" and community_id =="" and no_of_bedrooms == "":
        query = {"property_type":property_type_like}
        print(query)
    elif location_id == "" and community_id == "" and no_of_bedrooms != "":
        query = {"property_type": property_type_like, "no_of_bedrooms":no_of_bedrooms}
        print(query)
    elif location_id == "" and community_id != "" and no_of_bedrooms == "":
        query = {"property_type": property_type_like,"community_id":ObjectId(community_id)}
    elif location_id == "" and community_id != "" and no_of_bedrooms != "":
        query = {"property_type": property_type_like, "community_id": ObjectId(community_id),"no_of_bedrooms":no_of_bedrooms}
    elif location_id != "" and community_id == "" and no_of_bedrooms == "":
        query = {"location_id":ObjectId(location_id)}
        communities = community_col.find(query)
        communities_ids =[ ]
        for community in communities :
            communities_ids.append({"community_id":community["_id"]})
            if len(communities_ids)>0:
                query ={"$or":communities_ids,"property_type": property_type_like}
    elif location_id != "" and community_id =="" and no_of_bedrooms != "":
        query = {"location_id": ObjectId(location_id)}
        communities = community_col.find(query)
        communities_ids = []
        for community in communities:
            communities_ids.append({"community_id": community["_id"]})
            if len(communities_ids) > 0:
                query = {"$or": communities_ids, "property_type": property_type_like,"no_of_bedrooms":no_of_bedrooms}
    elif location_id != "" and community_id != "" and no_of_bedrooms == "":
        query = {"location_id": ObjectId(location_id)}
        communities = community_col.find(query)
        communities_ids = []
        for community in communities:
            communities_ids.append({"community_id": community["_id"]})
            if len(communities_ids) > 0:
                query = {"$or": communities_ids, "property_type": property_type_like,"community_id":ObjectId(community_id)}
    elif location_id != "" and community_id != "" and no_of_bedrooms != "":
        query = {"location_id": ObjectId(location_id)}
        communities = community_col.find(query)
        communities_ids = []
        for community in communities:
            communities_ids.append({"community_id": community["_id"]})
            if len(communities_ids) > 0:
                query = {"$or": communities_ids, "property_type": property_type_like,"community_id":ObjectId(community_id),"no_of_bedrooms":no_of_bedrooms}
    properties = property_col.find(query)
    return render_template("view_properties.html",properties=properties,get_communities_by_community_id=get_communities_by_community_id,get_leasings_by_property_id=get_leasings_by_property_id,is_rent_request_send=is_rent_request_send,is_appointment_request_send=is_appointment_request_send,get_amenities_by_community_id=get_amenities_by_community_id)


def get_amenities_by_community_id(community_id):
    query={"community_id":ObjectId(community_id)}
    amenities = amenities_col.find(query)
    return  amenities

def get_communities_by_community_id(community_id):
    query = {"_id": ObjectId(community_id)}
    communities = community_col.find_one(query)
    return  communities

@app.route("/appointment_request" , methods=['post'])
def appointment_request():
    property_id = request.form.get("property_id")
    return render_template("appointment_request.html",property_id=property_id)

@app.route("/appointment_request1", methods=['post'])
def appointment_request1():
    property_id = request.form.get("property_id")
    customer_id = session['customer_id']
    appointment_date = request.form.get("appointment_date")
    message = request.form.get("message")
    appointment_date.replace("T"," ")
    status = "Appointment Request Sent"
    query = {"property_id": ObjectId(property_id), "customer_id": ObjectId(customer_id), "appointment_date": appointment_date,"message":message ,"status": status}
    appointment_col.insert_one(query)
    return render_template("message.html", message="Appointment Request Sent to Leasing Officer")

@app.route("/view_appointment_request")
def view_appointment_request():
    property_id = request.args.get("property_id")
    query = {"property_id":ObjectId(property_id)}
    appointments = appointment_col.find(query)
    return render_template("view_appointment_request.html",appointments=appointments,get_customers_by_customer_id=get_customers_by_customer_id)

def get_customers_by_customer_id(customer_id):
    query = {"_id": ObjectId(customer_id)}
    customers = customer_col.find_one(query)
    return  customers

@app.route("/accept_appointment")
def accept_appointment():
    appointment_id = request.args.get("appointment_id")
    query ={"_id":ObjectId(appointment_id)}
    query2 = {"$set":{"status":"Request Accepted By Leasing Officer"}}
    appointment_col.update_one(query,query2)
    return render_template("message.html",message="Leasing Officer Accepted the appointment")

@app.route("/reject_appointment")
def reject_appointment():
    appointment_id = request.args.get("appointment_id")
    query ={"_id":ObjectId(appointment_id)}
    query2 = {"$set":{"status":"Request Rejected By Leasing Officer"}}
    appointment_col.update_one(query,query2)
    return render_template("message.html",message="Leasing Officer reject the appointment")

@app.route("/view_appointment")
def view_appointment():
    if session['role'] == 'customer':
        customer_id =  session['customer_id']
        query = {"customer_id":ObjectId(customer_id)}
    appointments = appointment_col.find(query)
    return render_template("view_appointment_request.html",appointments=appointments, get_customers_by_customer_id=get_customers_by_customer_id)


@app.route("/status_cancle", methods=['post'])
def status_cancle():
    appointment_id = request.form.get("appointment_id")
    status = request.form.get("status")
    query = {"_id": ObjectId(appointment_id)}
    query2 = {"$set": {"status": status}}
    appointment_col.update_one(query, query2)
    return render_template("message.html", message="Customer " +status+  " Rent Request")


@app.route("/add_leasing")
def add_leasing():
    property_id = request.args.get("property_id")
    return render_template("add_leasing.html",property_id=property_id)

@app.route("/add_leasing1", methods=['post'])
def add_leasing1():
    property_id = request.form.get("property_id")
    no_of_months = request.form.get("no_of_months")
    price = request.form.get("price")
    advance_deposite = request.form.get("advance_deposite")
    status = "Available"
    query = {"no_of_months": no_of_months, "price": price, "advance_deposite": advance_deposite, "status": status,"property_id":ObjectId(property_id)}
    leasings_col.insert_one(query)
    return render_template("message.html",message="Leasing added to the property successfully")


def get_leasings_by_property_id(property_id):
    query = {"property_id":ObjectId(property_id)}
    leasings= leasings_col.find(query)
    return  leasings



@app.route("/customer_registration")
def customer_registration():
    return render_template("customer_registration.html")


@app.route("/customer_registration_action", methods=['post'])
def customer_registration_action():
    name = request.form.get("name")
    email = request.form.get("email")
    password = request.form.get("password")
    phone = request.form.get("phone")
    gender = request.form.get("gender")
    age = request.form.get("age")
    query = {"$or":[{"email":email, "phone":phone}]}
    count = customer_col.count_documents(query)
    if count == 0:
        query= {"name":name, "email":email,"password":password,"phone":phone,"gender":gender,"age":age}
        customer_col.insert_one(query)
        return render_template("msg.html", message="Customer Registered Successfully")
    else:
        return  render_template("msg.html",message="duplicate details")


@app.route("/customer_login")
def customer_login():
    return render_template("customer_login.html")


@app.route("/customer_login_action", methods=['post'])
def customer_login_action():
    email = request.form.get("email")
    password = request.form.get("password")
    query={"email":email, "password":password}
    customer = customer_col.find_one(query)
    if customer is not None:
        session["customer_id"] = str(customer["_id"])
        session["role"] = "customer"
        return redirect("/customer_home")
    else:
        return render_template("message.html", message="Invalid Login Details")


@app.route("/customer_home")
def customer_home():
    customer_id = session['customer_id']
    query = {"_id":ObjectId(customer_id)}
    customers = customer_col.find(query)
    return render_template("customer_home.html",customers=customers)



@app.route("/rent_request")
def rent_request():
    leasing_id = request.args.get("leasing_id")
    property_id = request.args.get("property_id")
    leasing_officer_id = request.args.get("leasing_officer_id")
    query = {"_id":ObjectId(leasing_id)}
    leasing = leasings_col.find_one(query)
    property_id =leasing['property_id']
    query = {"_id":property_id}
    property = property_col.find_one(query)
    community_id =property['community_id']
    query = {"community_id":community_id}
    leasing_officer = leasing_officer_col.find_one(query)
    leasing_officer_id = leasing_officer['_id']
    customer_id =session['customer_id']
    today = datetime.datetime.now()
    status = "Request sent"
    query = {"customer_id":ObjectId(customer_id),"property_id":property_id,"today":today, "status":status,"leasing_officer_id":leasing_officer_id,"leasing_id":ObjectId(leasing_id)}
    rent_request_col.insert_one(query)
    return render_template("message.html", message="Rent Request send to the Leasing officer")

def is_rent_request_send(property_id):
    if session['role'] !='customer':
        return False
    customer_id = session['customer_id']
    query = {"property_id":property_id,"customer_id":ObjectId(customer_id)}
    count = rent_request_col.count_documents(query)
    if count == 0:
        return True
    else :
        return  False


def is_appointment_request_send(property_id):
    if session['role'] !='customer':
        return False
    customer_id = session['customer_id']
    query = {"property_id":property_id,"customer_id":ObjectId(customer_id)}
    count = appointment_col.count_documents(query)
    if count == 0:
        return True
    else :
        return  False

@app.route("/view_rent_request")
def view_rent_request():
    leasing_id = request.args.get("leasing_id")
    query = {"leasing_id":ObjectId(leasing_id)}
    rent_requests = rent_request_col.find(query)
    return render_template("view_rent_request.html",rent_requests=rent_requests,get_customers_by_customer_id=get_customers_by_customer_id,get_properties_by_property_id=get_properties_by_property_id,get_communities_by_community_id=get_communities_by_community_id,get_payments_by_rent_request_id=get_payments_by_rent_request_id)

@app.route("/set_status_accepted", methods=['post'])
def set_status_accepted():
    rent_request_id = request.form.get("rent_request_id")
    property_id = request.form.get("property_id")
    status = request.form.get("status")
    query = {"_id": ObjectId(rent_request_id)}
    query2 = {"$set": {"status": status}}
    rent_request_col.update_one(query, query2)
    query = {"property_id": ObjectId(property_id), "status":"Request sent"}
    query2 = {"$set": {"status": "Rental Request Suspended"}}
    rent_request_col.update_one(query, query2)
    return render_template("message.html", message="Leasing Officer " +status+  " Rent Request")

@app.route("/set_status_rejected", methods=['post'])
def set_status_rejected():
    rent_request_id = request.form.get("rent_request_id")
    property_id = request.form.get("property_id")
    status = request.form.get("status")
    query = {"_id": ObjectId(rent_request_id)}
    query2 = {"$set": {"status": status}}
    rent_request_col.update_one(query, query2)
    return render_template("message.html", message="Leasing Officer " +status+  " Rent Request")

def get_properties_by_property_id(property_id):
    query = {"_id":ObjectId(property_id)}
    properties = property_col.find_one(query)
    return  properties

def get_communities_by_community_id(community_id):
    query = {"_id":ObjectId(community_id)}
    communities = community_col.find_one(query)
    return  communities

@app.route("/view_rent")
def view_rent():
    if session['role']=='customer':
        customer_id = session['customer_id']
        query = {"customer_id": ObjectId(customer_id)}
    rent_requests = rent_request_col.find(query)
    return render_template("view_rent_request.html",rent_requests=rent_requests,get_customers_by_customer_id=get_customers_by_customer_id,get_properties_by_property_id=get_properties_by_property_id,get_communities_by_community_id=get_communities_by_community_id,get_payments_by_rent_request_id=get_payments_by_rent_request_id)

@app.route("/payment")
def payment():
    rent_request_id = request.args.get("rent_request_id")
    query = {"_id":ObjectId(rent_request_id)}
    rent_request = rent_request_col.find_one(query)
    property_id = rent_request['property_id']
    query = {"_id":ObjectId(property_id)}
    property = property_col.find_one(query)
    leasing_id = rent_request['leasing_id']
    query = {"_id": ObjectId(leasing_id)}
    leasing = leasings_col.find_one(query)
    advance_deposite = leasing['advance_deposite']
    return  render_template("payment.html", advance_deposite=advance_deposite, rent_request_id=rent_request_id,leasing_id=leasing_id,property_id=property_id)


@app.route("/payment1", methods=['post'])
def payment1():
    rent_request_id = request.form.get("rent_request_id")
    property_id = request.form.get("property_id")
    leasing_id = request.form.get("leasing_id")
    card_type = request.form.get("card_type")
    card_number = request.form.get("card_number")
    card_holder_name = request.form.get("card_holder_name")
    cvv = request.form.get("cvv")
    expiry_date = request.form.get("expiry_date")
    date = datetime.datetime.now()
    deposite_amount = request.form.get("deposite_amount")
    query = { "rent_request_id":ObjectId(rent_request_id),"card_type":card_type,"card_number":card_number,"card_holder_name":card_holder_name,"cvv":cvv,"expiry_date":expiry_date,"date":date,"deposite_amount":deposite_amount}
    payment_col.insert_one(query)
    query = {"_id":ObjectId(rent_request_id)}
    query1 ={"$set":{"status":"property rented"}}
    rent_request_col.update_one(query,query1)
    query = {"_id":ObjectId(property_id)}
    query1 = {"$set":{"status":"Not Available"}}
    property_col.update_one(query,query1)
    query = {"_id": ObjectId(leasing_id)}
    query1 = {"$set": {"status": "Not Available"}}
    leasings_col.update_one(query, query1)
    return render_template("cmsg.html", message="payment successfully")

def get_payments_by_rent_request_id(rent_request_id):
    query = {"rent_request_id":ObjectId(rent_request_id)}
    payments = payment_col.find(query)
    return  payments


@app.route("/logout")
def logout():
    session.clear()
    return  redirect("/")


app.run(debug=True)